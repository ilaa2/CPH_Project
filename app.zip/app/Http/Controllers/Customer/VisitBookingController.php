<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\TipeKunjungan;
use App\Models\Kunjungan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Inertia\Inertia;
use Midtrans\Config;
use Midtrans\Snap;

class VisitBookingController extends Controller
{
    /**
     * Menampilkan halaman landing kunjungan (intro/penjelasan).
     */
    public function landing()
    {
        return Inertia::render('Customer/KunjunganLanding');
    }

    /**
     * Menampilkan halaman formulir awal untuk membuat kunjungan.
     */
    public function index()
    {
        session()->forget('form_data_kunjungan');
        $tipeKunjungan = TipeKunjungan::all();

        return Inertia::render('Customer/Kunjungan', [
            'tipeKunjungan' => $tipeKunjungan,
        ]);
    }

    /**
     * Memvalidasi data dari form awal dan menyimpannya di sesi.
     */
    public function handleForm(Request $request)
    {
        $validated = $request->validate([
            'nama_lengkap'      => 'required|string|max:255',
            'no_hp'             => 'required|string|max:15',
            'tanggal_kunjungan' => 'required|date|after_or_equal:today',
            'jam_kunjungan'     => 'required|in:09:00,11:00,13:00,15:00',
            'tipe_kunjungan_id' => 'required|exists:tipe_kunjungan,id',
            'jumlah_dewasa'     => 'required|integer|min:0',
            'jumlah_anak'       => 'required|integer|min:0',
            'jumlah_balita'     => 'required|integer|min:0',
        ]);

        // CEK KETERSEDIAAN SLOT
        $isBooked = Kunjungan::where('tanggal', $validated['tanggal_kunjungan'])
            ->where('jam', $validated['jam_kunjungan'] . ':00')
            ->where('status', '!=', 'Batal')
            ->where(function ($q) {
                $q->where('payment_status', 'paid')
                  ->orWhere('payment_status', 'pending');
            })
            ->exists();

        if ($isBooked) {
            return back()->withInput()->withErrors(['jam_kunjungan' => 'Jam kunjungan ini sudah terisi. Silakan pilih jam lain.']);
        }

        $tipe = TipeKunjungan::find($validated['tipe_kunjungan_id']);
        if ($tipe && $tipe->nama_tipe === 'Umum' && $validated['jumlah_dewasa'] < 1) {
            return back()->withInput()->withErrors(['jumlah_dewasa' => 'Sewa Tempat memerlukan minimal 1 orang dewasa.']);
        }

        session()->put('form_data_kunjungan', $validated);

        return redirect()->route('kunjungan.konfirmasi');
    }

    /**
     * Menampilkan halaman konfirmasi dengan data dari sesi.
     */
    public function showKonfirmasi()
    {
        $dataFromSession = session()->get('form_data_kunjungan');

        if (!$dataFromSession) {
            return redirect()->route('kunjungan.index');
        }

        $detailTipe = TipeKunjungan::find($dataFromSession['tipe_kunjungan_id']);
        $totalBiaya = $this->calculateTotalCost($detailTipe, $dataFromSession);

        $jamLabels = [
            '09:00' => '09.00 – 11.00 WIB',
            '11:00' => '11.00 – 13.00 WIB',
            '13:00' => '13.00 – 15.00 WIB',
            '15:00' => '15.00 – 17.00 WIB',
        ];

        $dataKunjungan = array_merge($dataFromSession, [
            'nama_tipe'   => $detailTipe->nama_tipe,
            'jam_label'   => $jamLabels[$dataFromSession['jam_kunjungan']] ?? $dataFromSession['jam_kunjungan'],
            'total_biaya' => $totalBiaya,
        ]);

        return Inertia::render('Customer/KunjunganKonfirmasi', [
            'dataKunjungan' => $dataKunjungan,
        ]);
    }

    /**
     * Menyimpan data kunjungan final ke database dan generate Midtrans token.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama_lengkap'      => 'required|string|max:255',
            'no_hp'             => 'required|string|max:15',
            'tanggal_kunjungan' => 'required|date',
            'jam_kunjungan'     => 'required|in:09:00,11:00,13:00,15:00',
            'tipe_kunjungan_id' => 'required|exists:tipe_kunjungan,id',
            'jumlah_dewasa'     => 'required|integer|min:0',
            'jumlah_anak'       => 'required|integer|min:0',
            'jumlah_balita'     => 'required|integer|min:0',
        ]);

        $tipeKunjungan = TipeKunjungan::find($validated['tipe_kunjungan_id']);

        if ($tipeKunjungan && $tipeKunjungan->nama_tipe === 'Umum' && $validated['jumlah_dewasa'] < 1) {
            return back()->withInput()->withErrors(['jumlah_dewasa' => 'Sewa Tempat memerlukan minimal 1 orang dewasa.']);
        }

        // CEK LAGI KETERSEDIAAN SLOT (prevent race condition)
        $isBooked = Kunjungan::where('tanggal', $validated['tanggal_kunjungan'])
            ->where('jam', $validated['jam_kunjungan'] . ':00')
            ->where('status', '!=', 'Batal')
            ->where(function ($q) {
                $q->where('payment_status', 'paid')
                  ->orWhere('payment_status', 'pending');
            })
            ->exists();

        if ($isBooked) {
            return redirect()->route('kunjungan.index')->with('error', 'Maaf, jam kunjungan tersebut baru saja dibooking orang lain. Silakan pilih jadwal ulang.');
        }

        $finalTotalBiaya = $this->calculateTotalCost($tipeKunjungan, $validated);
        $user = Auth::user();

        $midtransOrderId = 'KNJ-' . strtoupper(Str::random(6)) . '-' . time();

        $kunjungan = Kunjungan::create([
            'user_id'           => $user->id,
            'tipe_id'           => $validated['tipe_kunjungan_id'],
            'tanggal'           => $validated['tanggal_kunjungan'],
            'jam'               => $validated['jam_kunjungan'] . ':00',
            'jumlah_dewasa'     => $validated['jumlah_dewasa'],
            'jumlah_anak'       => $validated['jumlah_anak'],
            'jumlah_balita'     => $validated['jumlah_balita'],
            'total_biaya'       => $finalTotalBiaya,
            'status'            => 'Menunggu Pembayaran',
            'payment_status'    => 'unpaid',
            'midtrans_order_id' => $midtransOrderId,
        ]);

        // Generate Midtrans Snap Token
        try {
            Config::$serverKey = config('midtrans.server_key');
            Config::$isProduction = config('midtrans.is_production');
            Config::$isSanitized = config('midtrans.is_sanitized');
            Config::$is3ds = config('midtrans.is_3ds');

            $payload = [
                'transaction_details' => [
                    'order_id' => $midtransOrderId,
                    'gross_amount' => (int) $finalTotalBiaya,
                ],
                'customer_details' => [
                    'first_name' => $validated['nama_lengkap'],
                    'email' => $user->email,
                    'phone' => $validated['no_hp'],
                ],
                'item_details' => [
                    [
                        'id' => 'KUNJUNGAN-' . $tipeKunjungan->id,
                        'name' => 'Kunjungan ' . $tipeKunjungan->nama_tipe,
                        'price' => (int) $finalTotalBiaya,
                        'quantity' => 1,
                    ]
                ],
                'callbacks' => [
                    'finish' => url('/customer/payment/finish'),
                    'unfinish' => url('/customer/payment/unfinish'),
                    'error' => url('/customer/payment/error'),
                ],
            ];

            $snapToken = Snap::getSnapToken($payload);
            $kunjungan->update(['snap_token' => $snapToken, 'payment_status' => 'pending']);
        } catch (\Exception $e) {
            Log::error('Midtrans Kunjungan Error: ' . $e->getMessage());
        }

        session()->forget('form_data_kunjungan');

        return redirect()->route('customer.kunjungan.payment', $kunjungan->id);
    }

    /**
     * Menampilkan detail satu kunjungan milik pelanggan.
     */
    public function show(Kunjungan $kunjungan)
    {
        // Use intval() to avoid strict type mismatch (string vs int)
        if (intval($kunjungan->user_id) !== intval(Auth::id())) {
            abort(403, 'AKSES DITOLAK');
        }

        $kunjungan->load(['tipe', 'ulasan.fotos', 'user']);

        return Inertia::render('Customer/Kunjungan/Show', [
            'kunjungan' => $kunjungan,
        ]);
    }

    /**
     * Menampilkan halaman pembayaran kunjungan.
     */
    public function showPayment(Kunjungan $kunjungan)
    {
        // Use intval() to avoid strict type mismatch (string vs int)
        if (intval($kunjungan->user_id) !== intval(Auth::id())) {
            abort(403, 'AKSES DITOLAK');
        }

        if ($kunjungan->payment_status === 'paid') {
            return redirect()->route('customer.kunjungan.show', $kunjungan->id);
        }

        $kunjungan->load('tipe');
        $snapToken = $kunjungan->snap_token;
        
        if (!$snapToken) {
            try {
                Config::$serverKey = config('midtrans.server_key');
                Config::$isProduction = config('midtrans.is_production');
                Config::$isSanitized = config('midtrans.is_sanitized');
                Config::$is3ds = config('midtrans.is_3ds');

                if (!$kunjungan->midtrans_order_id) {
                    $kunjungan->midtrans_order_id = 'KNJ-' . strtoupper(Str::random(6)) . '-' . time();
                }

                $user = Auth::user();
                
                $payload = [
                    'transaction_details' => [
                        'order_id' => $kunjungan->midtrans_order_id,
                        'gross_amount' => (int) $kunjungan->total_biaya,
                    ],
                    'customer_details' => [
                        'first_name' => $user->name,
                        'email' => $user->email,
                        'phone' => $user->phone ?? '',
                    ],
                    'item_details' => [
                        [
                            'id' => 'KUNJUNGAN-' . $kunjungan->tipe_id,
                            'name' => 'Kunjungan ' . ($kunjungan->tipe->nama_tipe ?? 'Edukatif'),
                            'price' => (int) $kunjungan->total_biaya,
                            'quantity' => 1,
                        ]
                    ],
                    'callbacks' => [
                        'finish' => url('/customer/payment/finish'),
                        'unfinish' => url('/customer/payment/unfinish'),
                        'error' => url('/customer/payment/error'),
                    ],
                ];

                $snapToken = Snap::getSnapToken($payload);
                $kunjungan->update([
                    'snap_token' => $snapToken,
                    'midtrans_order_id' => $kunjungan->midtrans_order_id,
                    'payment_status' => 'pending',
                ]);
            } catch (\Exception $e) {
                Log::error('Midtrans Snap Token Generation Error: ' . $e->getMessage());
                $snapToken = null;
            }
        }

        return Inertia::render('Customer/Kunjungan/PaymentProcess', [
            'kunjungan' => $kunjungan,
            'snapToken' => $snapToken,
            'clientKey' => config('midtrans.client_key'),
            'snapUrl' => config('midtrans.snap_url'),
        ]);
    }

    /**
     * Helper function untuk menghitung total biaya.
     */
    private function calculateTotalCost(TipeKunjungan $tipe, array $data): float
    {
        $biaya = 0;
        $jumlah_dewasa = $data['jumlah_dewasa'] ?? 0;
        $jumlah_anak = $data['jumlah_anak'] ?? 0;

        if ($tipe->nama_tipe === 'Umum') {
            // Dewasa 15.000, Anak 10.000, Balita Gratis
            $biaya = ($jumlah_dewasa * 15000) + ($jumlah_anak * 10000);
        } elseif ($tipe->nama_tipe === 'Outing Class') {
            if ($jumlah_anak < 30) {
                $biaya = 300000;
            } else {
                $biaya = $jumlah_anak * 10000;
            }
        } else {
            // Tipe lain default harga tiket per orang (Dewasa+Anak), Balita Gratis
            $totalPengunjung = $jumlah_dewasa + $jumlah_anak;
            $biaya = $totalPengunjung * ($tipe->harga_tiket ?? $tipe->biaya ?? 0);
        }

        return $biaya;
    }

    /**
     * Download Invoice Kunjungan (PDF).
     */
    public function downloadInvoice(Kunjungan $kunjungan)
    {
        // Use intval() to avoid strict type mismatch (string vs int)
        if (intval($kunjungan->user_id) !== intval(Auth::id())) {
            abort(403, 'Unauthorized');
        }

        // Hanya boleh download jika PAID atau status Selesai
        if ($kunjungan->payment_status !== 'paid' && $kunjungan->status !== 'Selesai') {
            abort(404, 'Invoice belum tersedia (Menunggu Pembayaran).');
        }

        $kunjungan->load(['tipe', 'user']);

        $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('pdf.invoice_kunjungan', [
            'kunjungan' => $kunjungan
        ]);

        return $pdf->stream('invoice-kunjungan-' . $kunjungan->id . '.pdf');
    }

    /**
     * Mark visit as completed by customer.
     */
    public function complete(Kunjungan $kunjungan)
    {
        // Use intval() to avoid strict type mismatch (string vs int)
        if (intval($kunjungan->user_id) !== intval(Auth::id())) {
            abort(403, 'Unauthorized');
        }

        if ($kunjungan->status !== 'Dijadwalkan') {
            return back()->with('error', 'Kunjungan tidak dapat diselesaikan saat ini.');
        }

        $kunjungan->update(['status' => 'Selesai']);

        return back()->with('success', 'Kunjungan telah selesai. Terima kasih atas kunjungan Anda!');
    }

    /**
     * Konfirmasi pembayaran berhasil dari frontend (Snap onSuccess callback).
     * Ini menjadi fallback jika Midtrans webhook belum sempat memproses.
     */
    public function confirmPayment(Kunjungan $kunjungan)
    {
        // Use intval() to avoid strict type mismatch (string vs int)
        if (intval($kunjungan->user_id) !== intval(Auth::id())) {
            abort(403);
        }

        // Hanya update jika belum paid (hindari duplikasi dengan webhook)
        if ($kunjungan->payment_status !== 'paid') {
            $kunjungan->update([
                'payment_status' => 'paid',
                'status' => 'Dijadwalkan',
                'paid_at' => now(),
            ]);

            Log::info('Kunjungan payment confirmed via frontend callback', [
                'kunjungan_id' => $kunjungan->id,
            ]);
        }

        return response()->json(['success' => true]);
    }

    /**
     * API untuk mengecek slot jam yang sudah terisi pada tanggal tertentu.
     */
    public function checkAvailability(Request $request)
    {
        $date = $request->query('date');

        if (!$date) {
            return response()->json(['bookedSlots' => []]);
        }

        $bookedSlots = Kunjungan::where('tanggal', $date)
            ->where('status', '!=', 'Batal')
            ->where(function ($q) {
                $q->where('payment_status', 'paid')
                  ->orWhere('payment_status', 'pending');
            })
            ->pluck('jam')
            ->map(function ($jam) {
                return substr($jam, 0, 5);
            })
            ->toArray();

        return response()->json([
            'bookedSlots' => $bookedSlots
        ]);
    }
}
